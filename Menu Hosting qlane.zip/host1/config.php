<?php
// Config

$zone_id = '642c79c06e97773e051195a871546db0';
$storeidd = '5WZT6whl21H2wT4-yB4ym-_OaJ2XlF0ZXIKVNNN5';

$storeid = '.qlane.my.id';
