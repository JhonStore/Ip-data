
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="make loading page with bootstrap and jquery">
    <meta name="author" content="SkyLight_Animation">
    <link rel="icon" href="https://l.top4top.io/p_2415ej9zh0.jpg">
 
    <title>Loading | By QLANENESIA</title>
    <link href="https://getbootstrap.com/docs/3.3/examples/cover/cover.css" rel="stylesheet">
 
    <!-- 1. bootstrap.css -->
    <link rel="stylesheet" type="text/css" href="">
    <style type="text/css">
        /* 5. letakkan code css di sini */
    </style>
 
</head>
<body>
    <!-- 4. letakkan code HTML untuk loader di sini -->
 
        <!-- content -->
            <div class="site-wrapper">
                <div class="site-wrapper-inner">
                    <div class="cover-container">
                        <div class="masthead clearfix">
                            <div class="inner">
                                <h3 class="masthead-brand">QLANENESIA</h3>
                                <ul class="nav masthead-nav">
                                    <li class="active"><a href="#"><a href="/">Home</a></a></li>
                                    <li><a href="#"<a href="https://wa.me/6285792407681">Youtube</a></li>
                                    <li><a href="https://wa.me/6285792407681">WhatsApp</a></li>
                                </ul>
                            </div>
                        </div>
                        </div>
                        <a href="https://i.ibb.co/xJb5wPG/IMG-20221009-WA0004.jpg"><img src="https://i.ibb.co/xJb5wPG/IMG-20221009-WA0004.jpg" width="500" heigh="500"<div> </a>
                          
                        <div class="inner cover">
                            <h1 class="cover-heading">HOME QLANENESIA</h1>
                            <p class="lead"><code>https://youtu.be/1Atfc3jjfDo</code></p>
                            <p class="lead">
                                <a href="https://rentry.co/storeqlanenesia" class="btn btn-lg btn-default">Visit</a>
                            </p>
                        </div>
                        <div class="position: fixed; bottom: 0px; left: 10px;width:130px;height:160px;"><a href="https://qlanenesia.blogspot.com" target="_blank"><img border="0" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj-fOdorLwxr3XkDWtFapoPzYuqqLOd_IBG1OgHD7AxQL5u5YRSXqdh3A5H-v_UpPLocjwq5N6Fc2_pPtm2eAMOABTs9YmZaTxagss1qa5TsDyncUQUkq9jbbwbKVF7mrYMWOFjifrOQkQG7wShT0IOIHSeYXeSc5aczd-bZca8gdLDefRCUZprdk_M/s510/20220812_192604.gif" title="My widget" alt="animasi bergerak gif" /></a><small><center><a href="https://blogger.googleusercontent.com"></a></center></small>
                        </div>
                        <div class="mastfoot">
                            <div class="inner">
                                <p>
                                    <a href="https://rentry.co/storeqlanenesia">Tutorial</a>.</a> by <a href="https://twitter.com/QLANE_CODEX">@QLANE_CODEX</a><br>
                                    content by <a href="https://github.com/QLANESTORE">QLANESTORE</a>.
                                </p>
                         <div class="inner cover">
                            <h1 class="cover-heading">LIST KEBUTUHAN</h1>
                            <p class="lead"><code>https://rentry.co/storeqlanenesia</code></p>
                            <p class="lead">
                                <a href="https://rentry.co/storeqlanenesia" class="btn btn-lg btn-default">VISIT IS LIST</a>
            </div>
        <!-- content -->
        <script src='https://faisal-fachrueza.googlecode.com/svn/efekbintang.js' type='text/javascript'></script>
         <!-- janggan asal redit -->
        <script>
        alert("WELCOME");
        alert("DI STORE QLANENESIA");
        alert("JANGAN LUPA SUBSCRIBE") 
        </script>
    </body>
</html>