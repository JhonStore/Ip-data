<?php
// Config

$zone_id = 'd371c7b002091190d1f353c79538fd63';
$storeidd = 'z_ugRlYZF6XNYeVzKvfAmZ47VrP_sHzwywblKeiE';

$storeid = '.qlane.biz.id';
